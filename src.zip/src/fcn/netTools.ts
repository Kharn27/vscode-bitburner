/** 
 * @param {NS} ns - L'interface NetScript
 * @param {string} server - Le serveur à scanner
 * @param {Set} serverList - La liste des serveurs parcourus
 * **/
export function multiScan(ns: NS, server = 'home', serverList = new Set<string>()): string[] {
    let serverConnections: string[] = ns.scan(server);
    ns.printf("Scanning server : " + server);
    serverConnections = serverConnections.filter(s => !serverList.has(s));
    serverConnections.forEach(s => {
        // if (s !== 'home') {
            serverList.add(s);
        // }
        return multiScan(ns, s, serverList);
    });
    return Array.from(serverList);
}

/** 
 * @param {NS} ns - L'interface NetScript
 * @param {string} server - Le serveur à scanner
 * @param {Set} serverList - La liste des serveurs parcourus
 * **/
export function filterScan(serverList: string[]): string[] {
    return serverList.filter((s) => s !== 'home' && !s.includes('bot-'));
}

/**
 * @param {NS} ns - L'interface NetScript
 * @param {string} serverName - Le nom du serveur interrogé
 * @param {number} ramNeeded - La ram nécessaire pour l'exécution du script
 * **/
export function getThreadCount(ns: NS, serverName: string, ramNeeded: number): number {
    const freeRam: number = ns.getServerMaxRam(serverName) - ns.getServerUsedRam(serverName);
    return Math.floor(freeRam / ramNeeded);
}

