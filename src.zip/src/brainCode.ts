import { NS } from '@ns';
import { multiScan, getThreadCount, filterScan } from '/fcn/netTools';

const scriptNames: string[] = ["/bin/grow.js", "/bin/hack.js", "/bin/weak.js"];
const scriptRam: number[] = [3];

export async function main(ns: NS): Promise<void> {
    const allServers: string[] = multiScan(ns);
    const extServers: string[] = filterScan(allServers);

    ns.tprint("**** Lancement du Bot ****");
    ns.tprint("" + allServers);
    ns.tprint("" + extServers);

    for (const i in scriptNames) {
        const s = scriptNames[i];
        scriptRam[i] = ns.getScriptRam(s);
        ns.tprint('Ram usage for ' + s + ' : ' + scriptRam[i] + ' Gb');
    }

    extServers.forEach(async (srv) => {
        ns.tprint("Copy des fichiers sur le server " + srv);
        await ns.scp(scriptNames, srv);
    });

    while (true) {
        extServers.forEach((srv) => {
            ns.tprint("Exécution a distance sur  " + srv);
            // Defines how much money a server should have before we hack it
            // In this case, it is set to 75% of the server's max money
            const moneyThresh = ns.getServerMaxMoney(srv) * 0.75;

            // Defines the maximum security level the target server can
            // have. If the target's security level is higher than this,
            // we'll weaken it before doing anything else
            const securityThresh = ns.getServerMinSecurityLevel(srv) + 5;

            // Define if the srv is Hackable
            const isHackable: boolean = ns.getHackingLevel() >= ns.getServerRequiredHackingLevel(srv);
            let availableThread = 0;
            if (ns.hasRootAccess(srv)) {

                if (ns.getServerSecurityLevel(srv) > securityThresh && isHackable) {
                    availableThread = getThreadCount(ns, srv, scriptRam[2]);
                    if (availableThread > 0) {
                        // If the server's security level is above our threshold, weaken it
                        ns.exec(scriptNames[2], srv, availableThread, srv);
                    }
                } else if (ns.getServerMoneyAvailable(srv) < moneyThresh && isHackable) {
                    availableThread = getThreadCount(ns, srv, scriptRam[0]);
                    if (availableThread > 0) {
                        // If the server's money is less than our threshold, grow it
                        ns.exec(scriptNames[0], srv, availableThread, srv);
                    }
                } else if (isHackable) {
                    availableThread = getThreadCount(ns, srv, scriptRam[1]);
                    if (availableThread > 0) {
                        // Otherwise, hack it
                        ns.exec(scriptNames[1], srv, availableThread, srv);
                    }
                }
            } else {
                ns.tprint("Piratage de  " + srv);
                ns.run("bin/attackServer.js", 1, srv);
            }
        });
        await ns.sleep(20);
    }


    // for (const server in servers) {
    //     ns.scp(["/bin/grow.js","/bin/grow.js","/bin/hack.js",])

    //     ns.tprint("" + server);
    // }

}